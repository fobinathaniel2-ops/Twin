import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

const bridge = MethodChannel('twin/native'); // talks to MainActivity.kt

// Palette: Deep Teal, Coral, Bone, Night
const teal = Color(0xFF0F3D3E);
const coral = Color(0xFFFF6B4A);
const bone = Color(0xFFF3EFE7);
const night = Color(0xFF0E1514);

void main() => runApp(const TwinApp());

TextStyle display(double s, Color c) =>
    TextStyle(fontSize: s, fontWeight: FontWeight.w800, letterSpacing: -1.2, height: 1.02, color: c);

ThemeData buildTheme(Brightness b) {
  final dark = b == Brightness.dark;
  final scheme = ColorScheme.fromSeed(
    seedColor: teal,
    brightness: b,
    primary: dark ? coral : teal,
    secondary: coral,
    surface: dark ? night : bone,
  );
  return ThemeData(useMaterial3: true, colorScheme: scheme, scaffoldBackgroundColor: scheme.surface);
}

class TwinApp extends StatelessWidget {
  const TwinApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Twin',
        debugShowCheckedModeBanner: false,
        theme: buildTheme(Brightness.light),
        darkTheme: buildTheme(Brightness.dark),
        home: const Home(),
      );
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> with WidgetsBindingObserver {
  Map<dynamic, dynamic>? status;
  List<dynamic> apps = [];
  String q = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    load();
  }

  @override
  void dispose() {
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState s) {
    if (s == AppLifecycleState.resumed) load();
  }

  Future<void> load() async {
    try {
      final s = await bridge.invokeMethod<Map<dynamic, dynamic>>('status');
      var a = <dynamic>[];
      if (s != null && (s['inProfile'] == true || s['profileExists'] == true)) {
        a = await bridge.invokeMethod<List<dynamic>>('apps') ?? [];
      }
      if (mounted) setState(() { status = s; apps = a; });
    } catch (e) {
      snack('Error: $e');
    }
  }

  void snack(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(m)));
  }

  Future<void> op(String op, String pkg) async {
    final r = await bridge.invokeMethod<String>('op', {'op': op, 'pkg': pkg});
    snack(r ?? 'Done');
    if (status?['inProfile'] == true) load();
  }

  Future<void> provision() async {
    try {
      await bridge.invokeMethod('provision');
    } on PlatformException catch (e) {
      snack('Could not start setup: ${e.message}');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final s = status;
    if (s == null) return const Scaffold(body: Center(child: CircularProgressIndicator()));
    final inProfile = s['inProfile'] == true;
    final exists = s['profileExists'] == true;
    final title = inProfile ? 'Inside your\nclone space.' : exists ? 'Pick an app\nto clone.' : 'Two of\neverything.';
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(24, 24, 24, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(title, style: display(40, cs.onSurface)),
            const SizedBox(height: 20),
            Expanded(child: (inProfile || exists) ? appList(inProfile, cs) : setup(s, cs)),
          ]),
        ),
      ),
    );
  }

  Widget circle(Color c) => Container(width: 150, height: 150, decoration: BoxDecoration(color: c, shape: BoxShape.circle));

  Widget perk(ColorScheme cs, IconData i, String t) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 8),
        child: Row(children: [Icon(i, color: coral), const SizedBox(width: 14), Text(t, style: const TextStyle(fontSize: 16))]),
      );

  Widget setup(Map<dynamic, dynamic> s, ColorScheme cs) {
    final ok = s['canProvision'] == true;
    return ListView(children: [
      SizedBox(
        height: 170,
        child: Stack(children: [
          Positioned(left: 20, top: 10, child: circle(cs.primary.withOpacity(.9))),
          Positioned(left: 110, top: 10, child: circle(coral.withOpacity(.9))),
        ]),
      ),
      const SizedBox(height: 16),
      perk(cs, Icons.block, 'No ads, ever'),
      perk(cs, Icons.wifi_off, 'No internet permission'),
      perk(cs, Icons.lock_outline, 'Clones stay on this phone'),
      const SizedBox(height: 24),
      FilledButton(
        onPressed: ok ? provision : null,
        style: FilledButton.styleFrom(minimumSize: const Size.fromHeight(56)),
        child: const Text('Create clone space', style: TextStyle(fontSize: 17)),
      ),
      if (!ok)
        Padding(
          padding: const EdgeInsets.only(top: 12),
          child: Text(
            s['managedUsers'] == false
                ? 'This Android device does not expose managed profiles.'
                : s['profileExists'] == true
                    ? 'A managed profile already exists on this device.'
                    : 'Android is currently not allowing profile setup.',
            style: TextStyle(color: cs.onSurface.withOpacity(.6)),
          ),
        ),
    ]);
  }

  Widget appList(bool inProfile, ColorScheme cs) {
    final shown = apps.where((a) => (a['name'] as String).toLowerCase().contains(q.toLowerCase())).toList();
    return Column(children: [
      TextField(
        onChanged: (v) => setState(() => q = v),
        decoration: InputDecoration(
          prefixIcon: const Icon(Icons.search),
          hintText: 'Search apps',
          filled: true,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(28), borderSide: BorderSide.none),
        ),
      ),
      const SizedBox(height: 8),
      Expanded(
        child: shown.isEmpty
            ? Center(
                child: Text(
                  inProfile ? 'Nothing cloned yet.\nOpen Twin on your main side and tap Clone.' : 'No apps found.',
                  textAlign: TextAlign.center,
                  style: TextStyle(color: cs.onSurface.withOpacity(.6)),
                ),
              )
            : ListView.builder(
                itemCount: shown.length,
                itemBuilder: (_, i) {
                  final a = shown[i];
                  final pkg = a['pkg'] as String;
                  final frozen = a['frozen'] == true;
                  return ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: ClipRRect(
                      borderRadius: BorderRadius.circular(12),
                      child: Image.memory(a['icon'] as Uint8List, width: 44, height: 44, gaplessPlayback: true),
                    ),
                    title: Text(a['name'] as String, style: const TextStyle(fontWeight: FontWeight.w600)),
                    subtitle: inProfile ? Text(frozen ? 'Frozen' : 'Active') : null,
                    trailing: inProfile
                        ? Row(mainAxisSize: MainAxisSize.min, children: [
                            Switch(value: frozen, onChanged: (v) => op(v ? 'freeze' : 'unfreeze', pkg)),
                            IconButton(icon: const Icon(Icons.delete_outline), onPressed: () => op('remove', pkg)),
                          ])
                        : FilledButton.tonal(onPressed: () => op('clone', pkg), child: const Text('Clone')),
                  );
                },
              ),
      ),
    ]);
  }
}
