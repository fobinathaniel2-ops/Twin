package com.example.twin

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.pm.LauncherApps
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

class MainActivity : FlutterActivity() {
    private fun dpm() = getSystemService(DevicePolicyManager::class.java)
    private fun inProfile() = dpm().isProfileOwnerApp(packageName)

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "twin/native")
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "status" -> {
                        val la = getSystemService(LauncherApps::class.java)
                        val pm = packageManager
                        val managedUsers = pm.hasSystemFeature(PackageManager.FEATURE_MANAGED_USERS)
                        val profiles = if (Build.VERSION.SDK_INT >= 21) la.profiles else emptyList()
                        val profileExists = profiles.size > 1
                        val provisioningAllowed = if (Build.VERSION.SDK_INT >= 24) {
                            try {
                                dpm().isProvisioningAllowed(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                            } catch (_: Exception) { false }
                        } else true

                        result.success(
                            mapOf(
                                "inProfile" to inProfile(),
                                "profileExists" to profileExists,
                                "canProvision" to (managedUsers && !profileExists && provisioningAllowed),
                                "managedUsers" to managedUsers,
                                "provisioningAllowed" to provisioningAllowed,
                                "sdk" to Build.VERSION.SDK_INT
                            )
                        )
                    }
                    "apps" -> Thread {
                        val list = loadApps()
                        runOnUiThread { result.success(list) }
                    }.start()
                    "provision" -> {
                        try {
                            val i = Intent(DevicePolicyManager.ACTION_PROVISION_MANAGED_PROFILE)
                            i.putExtra(
                                DevicePolicyManager.EXTRA_PROVISIONING_DEVICE_ADMIN_COMPONENT_NAME,
                                ComponentName(this, AdminReceiver::class.java)
                            )
                            startActivityForResult(i, 77)
                            result.success(null)
                        } catch (e: Exception) {
                            result.error("provision", "${e.javaClass.simpleName}: ${e.message}", null)
                        }
                    }
                    "op" -> {
                        val op = call.argument<String>("op") ?: ""
                        val pkg = call.argument<String>("pkg") ?: ""
                        if (inProfile()) {
                            result.success(Ops.run(this, op, pkg))
                        } else {
                            try {
                                val i = Intent("com.example.twin.CLONE")
                                i.putExtra("op", op)
                                i.putExtra("pkg", pkg)
                                startActivity(i)
                                result.success("Sent to your clone space")
                            } catch (e: Exception) {
                                result.success("Clone space is not ready yet")
                            }
                        }
                    }
                    else -> result.notImplemented()
                }
            }
    }

    private fun loadApps(): List<Map<String, Any>> {
        val pm = packageManager
        val q = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val profile = inProfile()
        val admin = ComponentName(this, AdminReceiver::class.java)
        return pm.queryIntentActivities(q, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { ri ->
                val pkg = ri.activityInfo.packageName
                var frozen = false
                if (profile && Build.VERSION.SDK_INT >= 24) {
                    frozen = try { dpm().isPackageSuspended(admin, pkg) } catch (e: Exception) { false }
                }
                mapOf<String, Any>(
                    "name" to ri.loadLabel(pm).toString(),
                    "pkg" to pkg,
                    "frozen" to frozen,
                    "icon" to icon(ri.loadIcon(pm))
                )
            }
            .sortedBy { (it["name"] as String).lowercase() }
    }

    private fun icon(d: Drawable): ByteArray {
        val s = 96
        val bmp = Bitmap.createBitmap(s, s, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, s, s)
        d.draw(Canvas(bmp))
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
        return out.toByteArray()
    }
}
