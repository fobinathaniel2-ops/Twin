package com.example.twin

import android.app.admin.DeviceAdminReceiver
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build

class AdminReceiver : DeviceAdminReceiver() {
    override fun onProfileProvisioningComplete(context: Context, intent: Intent) {
        Setup.finish(context)
    }
}

object Setup {
    // Runs inside the clone space (idempotent).
    fun finish(ctx: Context) {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        if (!dpm.isProfileOwnerApp(ctx.packageName)) return
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        dpm.setProfileName(admin, "Twin")
        dpm.setProfileEnabled(admin)
        ctx.packageManager.setComponentEnabledSetting(
            ComponentName(ctx, CloneActivity::class.java),
            PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
            PackageManager.DONT_KILL_APP
        )
        val f = IntentFilter("com.example.twin.CLONE")
        f.addCategory(Intent.CATEGORY_DEFAULT)
        dpm.addCrossProfileIntentFilter(admin, f, DevicePolicyManager.FLAG_PARENT_CAN_ACCESS_MANAGED)
    }
}

object Ops {
    fun run(ctx: Context, op: String, pkg: String): String {
        val dpm = ctx.getSystemService(DevicePolicyManager::class.java)
        val admin = ComponentName(ctx, AdminReceiver::class.java)
        if (!dpm.isProfileOwnerApp(ctx.packageName)) return "Not inside the clone space"
        return try {
            when (op) {
                "clone" -> {
                    if (Build.VERSION.SDK_INT >= 28) {
                        dpm.setApplicationHidden(admin, pkg, false)
                        if (dpm.installExistingPackage(admin, pkg)) "Cloned. Look for the badged copy in your launcher." else "Could not clone this app"
                    } else "Cloning needs Android 9 or newer"
                }
                "freeze", "unfreeze" -> {
                    if (Build.VERSION.SDK_INT >= 24) {
                        dpm.setPackagesSuspended(admin, arrayOf(pkg), op == "freeze")
                        if (op == "freeze") "Frozen" else "Unfrozen"
                    } else "Freezing needs Android 7 or newer"
                }
                "remove" -> {
                    dpm.setApplicationHidden(admin, pkg, true)
                    "Removed from clone space"
                }
                else -> "Unknown action"
            }
        } catch (e: Exception) {
            "Failed: ${e.message}"
        }
    }
}
