package com.example.twin

import android.app.Activity
import android.os.Bundle
import android.widget.Toast

// Receives forwarded requests from the main side, runs inside the clone space.
class CloneActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val op = intent.getStringExtra("op")
        val pkg = intent.getStringExtra("pkg")
        if (op != null && pkg != null) {
            Toast.makeText(this, Ops.run(this, op, pkg), Toast.LENGTH_LONG).show()
        }
        finish()
    }
}
