package com.example.twin

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.Intent
import android.os.Build
import android.os.Bundle

/**
 * Handles the Android 12+ DPC provisioning callbacks and keeps the legacy
 * provisioning callback available for older Android releases.
 */
class ProvisionActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        when (intent.action) {
            DevicePolicyManager.ACTION_GET_PROVISIONING_MODE -> {
                val allowed = if (Build.VERSION.SDK_INT >= 31) {
                    intent.getIntegerArrayListExtra(
                        DevicePolicyManager.EXTRA_PROVISIONING_ALLOWED_PROVISIONING_MODES
                    )
                } else null

                val managedProfile = DevicePolicyManager.PROVISIONING_MODE_MANAGED_PROFILE
                if (allowed == null || allowed.contains(managedProfile)) {
                    setResult(
                        RESULT_OK,
                        Intent().putExtra(
                            DevicePolicyManager.EXTRA_PROVISIONING_MODE,
                            managedProfile
                        )
                    )
                } else {
                    setResult(RESULT_CANCELED)
                }
                finish()
            }

            DevicePolicyManager.ACTION_ADMIN_POLICY_COMPLIANCE -> {
                // At this point Android has created the managed profile and
                // assigned Twin as its profile owner. Apply our profile setup.
                Setup.finish(applicationContext)
                setResult(RESULT_OK)
                finish()
            }

            else -> {
                setResult(RESULT_CANCELED)
                finish()
            }
        }
    }
}
